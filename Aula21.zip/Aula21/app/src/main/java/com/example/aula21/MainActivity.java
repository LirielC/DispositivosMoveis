package com.example.aula21;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.View;


import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
//F
public class MainActivity extends AppCompatActivity {
    //I
    EditText edtPeso, edtAltura, edtImc, edtSituacao;
    RadioButton rbFeminino, rbMasculino;
    CheckBox chkIdade;
    //F
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//I
        edtPeso= (EditText) findViewById(R.id.editTextPeso);
        edtAltura=(EditText) findViewById(R.id.editTextAltura);
        edtImc=(EditText) findViewById(R.id.editTextImc);
        edtSituacao=(EditText) findViewById(R.id.editTextSituacao);
        rbFeminino=(RadioButton) findViewById(R.id.radioFeminino);
        rbMasculino=(RadioButton) findViewById(R.id.radioMasculino);
        chkIdade=(CheckBox) findViewById(R.id.checkIdade);
//F
    }
    //I
    public void verificar(View v) {
        // entrada
        double peso, altura, imc = 0;
        boolean idade; // true - marcado, false - desmarcado
        int sexo; // 1 - feminino, 2 - masculino
        String situacao = "XXXXXXXXXXXX";

        peso = Double.parseDouble(edtPeso.getText().toString());
        altura = Double.parseDouble(edtAltura.getText().toString());

        // Checkbox idade
        if (chkIdade.isChecked()) {
            idade = true;
        } else {
            idade = false;
        }

        // RadioButton sexo
        if (rbFeminino.isChecked()) {
            sexo = 1;
        } else {
            sexo = 2;
        }

        // processamento
        imc = peso / Math.pow(altura, 2);

        // Tabela de classificação (exemplo adaptado por sexo)
        switch (sexo) {
            case 1: // Feminino
                if (imc < 19.1) {
                    situacao = "Abaixo do peso";
                } else if (imc < 25.8) {
                    situacao = "Peso normal";
                } else if (imc < 27.3) {
                    situacao = "Marginalmente acima do peso";
                } else if (imc < 32.3) {
                    situacao = "Acima do peso ideal";
                } else {
                    situacao = "Obeso";
                }
                break;

            case 2: // Masculino
                if (imc < 20.7) {
                    situacao = "Abaixo do peso";
                } else if (imc < 26.4) {
                    situacao = "Peso normal";
                } else if (imc < 27.8) {
                    situacao = "Marginalmente acima do peso";
                } else if (imc < 31.1) {
                    situacao = "Acima do peso ideal";
                } else {
                    situacao = "Obeso";
                }
                break;
        }

        // saída
        edtImc.setText(String.format("%.2f", imc));
        edtSituacao.setText(situacao);
    }

}






