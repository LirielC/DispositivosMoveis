package com.example.aula4;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

   private static final String TAG = "MinhaAtividade"; 

  @Override
   protected void onCreate(Bundle savedInstanceState) {
     super.onCreate(savedInstanceState);
     setContentView(R.layout.activity_main);
     Toast toast = Toast.makeText(getApplicationContext(), "A atividade foi CRIADA!!!", Toast.LENGTH_LONG);
     toast.show();
     Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onCreate()." + "Em Info/Informações.");
     Log.d(TAG, "  " + getLocalClassName() + " Executou o método: onCreate()." + "Em Debug/Depuração.");
     Log.e(TAG, "  " + getLocalClassName() + " Executou o método: onCreate()." + "Em Error/Erro.");
     Log.v(TAG, "  " + getLocalClassName() + " Executou o método: onCreate()." + "Em Verbose/Detalhado.");
     Log.w(TAG, "  " + getLocalClassName() + " Executou o método: onCreate()." + "Em Warn/Aviso."); 
   } 
   public void sair(View v){
        finish();
   }

    @Override
    protected void onStart() {
         Toast toast = Toast.makeText(getApplicationContext(),             "A atividade INICIOU !!!", Toast.LENGTH_LONG);
         toast.show();
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onStart().");
         super.onStart();
    } 
    @Override
    protected void onResume() {
         Toast toast = Toast.makeText(getApplicationContext(),             "A atividade RETORNOU !!!", Toast.LENGTH_LONG);
         toast.show();         
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onResume().");
         int a = 5 * 4;
         Log.i(TAG, "  " + getLocalClassName() + " O valor de a=" + a);
        super.onResume();
     } 
    @Override
    protected void onPause() {
         Toast toast = Toast.makeText(getApplicationContext(),             "A atividade entrou em PAUSA !!!", Toast.LENGTH_LONG);
         toast.show();
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onPause().");
        super.onPause();
     } 
    @Override
    protected void onStop() {
         Toast toast = Toast.makeText(getApplicationContext(),                 "A atividade PAROU !!!", Toast.LENGTH_LONG);
         toast.show();
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onStop().");
        super.onStop();
     }
    @Override
    protected void onRestart() {
         Toast toast = Toast.makeText(getApplicationContext(),             "A atividade REINICIOU !!!", Toast.LENGTH_LONG);
         toast.show();
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onRestart().");
        super.onRestart();
     }
     @Override
     protected void onDestroy() {
         Toast toast = Toast.makeText(getApplicationContext(),                 "A atividade ENCERROU !!!", Toast.LENGTH_LONG);
         toast.show();
         Log.i(TAG, "  " + getLocalClassName() + " Executou o método: onDestroy().");
        super.onDestroy();
     }
 }