package com.example.aula5;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void navegador(View v) {
        Uri uri = null;
        Intent intent = null;
        uri = Uri.parse("http://www.uezo.rj.gov.br/");
        intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void mapa(View v) {
        Uri uri = null;
        Intent intent = null;
        uri = Uri.parse("geo:0,0?q=avenida+manuel+caldera+de+alvarenga, rio de janeiro");
        intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void tela2(View v) {
        Intent intent = null;
        intent = new Intent(getApplicationContext(), Tela2Activity.class);
        startActivity(intent);
    }
}