package com.example.aula52;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextValor1;
    private EditText editTextValor2;
    private EditText editTextRetorno;

    // ActivityResultLauncher para receber o resultado da Tela2
    private ActivityResultLauncher<Intent> tela2Launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            double resultado = data.getDoubleExtra("resultado", 0.0);
                            editTextRetorno.setText(String.valueOf(resultado));
                        }
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextValor1 = findViewById(R.id.editTextValor1);
        editTextValor2 = findViewById(R.id.editTextValor2);
        editTextRetorno = findViewById(R.id.editTextRetorno);
    }

    public void irParaTelaSoma(View view) {
        String valor1Str = editTextValor1.getText().toString().trim();
        String valor2Str = editTextValor2.getText().toString().trim();

        if (valor1Str.isEmpty() || valor2Str.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha ambos os valores", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double valor1 = Double.parseDouble(valor1Str);
            double valor2 = Double.parseDouble(valor2Str);

            Intent intent = new Intent(getApplicationContext(), Tela2.class);
            intent.putExtra("valor1", valor1);
            intent.putExtra("valor2", valor2);
            tela2Launcher.launch(intent);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor, insira valores numéricos válidos", Toast.LENGTH_SHORT).show();
        }
    }
}