package com.example.aula52;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Tela2 extends AppCompatActivity {

    private EditText editTextValor1;
    private EditText editTextValor2;
    private TextView textViewResposta;
    private double valor1;
    private double valor2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        editTextValor1 = findViewById(R.id.editTextValor1Tela2);
        editTextValor2 = findViewById(R.id.editTextValor2Tela2);
        textViewResposta = findViewById(R.id.textViewResposta);

        Intent intent = getIntent();
        valor1 = intent.getDoubleExtra("valor1", 0.0);
        valor2 = intent.getDoubleExtra("valor2", 0.0);

        editTextValor1.setText(String.valueOf(valor1));
        editTextValor2.setText(String.valueOf(valor2));
    }

    public void calcularSoma(View view) {
        double resultado = valor1 + valor2;
        textViewResposta.setText("Resposta: " + resultado);
    }

    public void voltarTelaPrincipal(View view) {
        Intent intent = new Intent();
        intent.putExtra("resultado", valor1 + valor2);
        setResult(RESULT_OK, intent);
        finish();
    }
}